#!/bin/bash
python runtime/startclient.py "$@"
